#include "CameraCapture.h"
#include <mferror.h>
#include <mfobjects.h>
#include <algorithm>
#include <cwctype>
#include <cstring>

using Microsoft::WRL::ComPtr;

static std::wstring LowerCopy(std::wstring value)
{
    std::transform(value.begin(), value.end(), value.begin(),
        [](wchar_t ch) { return static_cast<wchar_t>(std::towlower(ch)); });
    return value;
}

bool CameraCapture::LooksLikeCanonEos(const std::wstring& name)
{
    const std::wstring lower = LowerCopy(name);
    return lower.find(L"canon") != std::wstring::npos ||
           lower.find(L"eos") != std::wstring::npos;
}

std::vector<CameraInfo> CameraCapture::Enumerate()
{
    std::vector<CameraInfo> out;
    ComPtr<IMFAttributes> attr;
    IMFActivate** devs = nullptr;
    UINT32 count = 0;

    if (FAILED(MFCreateAttributes(&attr, 1)))
        return out;

    attr->SetGUID(MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE,
                  MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_GUID);

    if (FAILED(MFEnumDeviceSources(attr.Get(), &devs, &count)))
        return out;

    for (UINT32 i = 0; i < count; ++i) {
        WCHAR* name = nullptr;
        UINT32 nameLen = 0;
        WCHAR* link = nullptr;
        UINT32 linkLen = 0;

        devs[i]->GetAllocatedString(
            MF_DEVSOURCE_ATTRIBUTE_FRIENDLY_NAME,
            &name, &nameLen);

        devs[i]->GetAllocatedString(
            MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_SYMBOLIC_LINK,
            &link, &linkLen);

        out.push_back({
            name ? name : L"Camera",
            link ? link : L""
        });

        CoTaskMemFree(name);
        CoTaskMemFree(link);
        devs[i]->Release();
    }

    CoTaskMemFree(devs);
    return out;
}

bool CameraCapture::RequestRgb32(std::wstring& error)
{
    ComPtr<IMFMediaType> type;
    HRESULT hr = MFCreateMediaType(&type);
    if (FAILED(hr)) {
        error = L"Could not create RGB32 media type";
        return false;
    }

    type->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
    type->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_RGB32);

    hr = reader_->SetCurrentMediaType(
        MF_SOURCE_READER_FIRST_VIDEO_STREAM,
        nullptr,
        type.Get());

    if (FAILED(hr)) {
        error = L"Media Foundation could not convert this camera to RGB32";
        return false;
    }

    ComPtr<IMFMediaType> actual;
    hr = reader_->GetCurrentMediaType(
        MF_SOURCE_READER_FIRST_VIDEO_STREAM,
        &actual);

    if (FAILED(hr)) {
        error = L"Could not query negotiated camera format";
        return false;
    }

    UINT32 width = 0, height = 0;
    hr = MFGetAttributeSize(actual.Get(), MF_MT_FRAME_SIZE, &width, &height);
    if (FAILED(hr) || width == 0 || height == 0) {
        error = L"Camera returned an invalid frame size";
        return false;
    }

    w_ = width;
    h_ = height;
    return true;
}

bool CameraCapture::ConfigureCanonEos(std::wstring& error)
{
    // EOS Webcam Utility behaves more reliably when Media Foundation owns
    // conversion/processing instead of trying to force one of its unusual
    // exposed native formats manually.
    return RequestRgb32(error);
}

bool CameraCapture::ConfigureGeneric(std::wstring& error)
{
    // Generic UVC/virtual webcams usually expose useful native formats such as
    // NV12, YUY2, MJPG or RGB32. Keep the device's preferred native type first,
    // then ask Media Foundation to insert the appropriate converter to RGB32.
    //
    // If the default native type cannot be converted, try every advertised
    // native format. This avoids Canon-specific assumptions while supporting a
    // broad range of ordinary USB webcams and virtual-camera devices.
    ComPtr<IMFMediaType> nativeType;

    if (SUCCEEDED(reader_->GetNativeMediaType(
            MF_SOURCE_READER_FIRST_VIDEO_STREAM, 0, &nativeType))) {
        reader_->SetCurrentMediaType(
            MF_SOURCE_READER_FIRST_VIDEO_STREAM,
            nullptr,
            nativeType.Get());

        if (RequestRgb32(error))
            return true;
    }

    for (DWORD index = 0;; ++index) {
        nativeType.Reset();

        HRESULT hr = reader_->GetNativeMediaType(
            MF_SOURCE_READER_FIRST_VIDEO_STREAM,
            index,
            &nativeType);

        if (hr == MF_E_NO_MORE_TYPES)
            break;
        if (FAILED(hr))
            continue;

        GUID major = GUID_NULL;
        if (FAILED(nativeType->GetGUID(MF_MT_MAJOR_TYPE, &major)) ||
            major != MFMediaType_Video)
            continue;

        hr = reader_->SetCurrentMediaType(
            MF_SOURCE_READER_FIRST_VIDEO_STREAM,
            nullptr,
            nativeType.Get());

        if (FAILED(hr))
            continue;

        std::wstring conversionError;
        if (RequestRgb32(conversionError))
            return true;
    }

    error = L"No usable generic webcam video format could be converted to RGB32";
    return false;
}

bool CameraCapture::Open(const CameraInfo& info, std::wstring& error)
{
    Close();

    deviceName_ = info.name;
    mode_ = LooksLikeCanonEos(info.name)
        ? Mode::CanonEosCompatibility
        : Mode::GenericMediaFoundation;

    ComPtr<IMFAttributes> attr;
    ComPtr<IMFMediaSource> source;

    if (FAILED(MFCreateAttributes(&attr, 2))) {
        error = L"MFCreateAttributes failed";
        return false;
    }

    attr->SetGUID(
        MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE,
        MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_GUID);

    attr->SetString(
        MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_SYMBOLIC_LINK,
        info.symbolicLink.c_str());

    HRESULT hr = MFCreateDeviceSource(attr.Get(), &source);
    if (FAILED(hr)) {
        error = L"Could not open camera";
        return false;
    }

    // IMPORTANT: Keep Source Reader creation identical to the known-good
    // V2-X.1 capture path. Camera-specific compatibility belongs in media-type
    // negotiation AFTER the reader exists. Adding ENABLE_VIDEO_PROCESSING here
    // caused both EOS Webcam Utility and physical UVC cameras such as C920 to
    // fail during MFCreateSourceReaderFromMediaSource.
    ComPtr<IMFAttributes> readerAttr;
    hr = MFCreateAttributes(&readerAttr, 4);
    if (FAILED(hr)) {
        error = L"Could not create source-reader attributes";
        return false;
    }

    readerAttr->SetUINT32(
        MF_SOURCE_READER_ENABLE_ADVANCED_VIDEO_PROCESSING, TRUE);
    readerAttr->SetUINT32(
        MF_READWRITE_DISABLE_CONVERTERS, FALSE);
    readerAttr->SetUINT32(
        MF_READWRITE_ENABLE_HARDWARE_TRANSFORMS, TRUE);
    readerAttr->SetUINT32(
        MF_SOURCE_READER_DISABLE_DXVA, FALSE);

    hr = MFCreateSourceReaderFromMediaSource(
        source.Get(),
        readerAttr.Get(),
        &reader_);

    if (FAILED(hr)) {
        wchar_t code[32]{};
        swprintf_s(code, L"0x%08X", static_cast<unsigned int>(hr));
        error = L"Could not create source reader (HRESULT " +
                std::wstring(code) + L")";
        return false;
    }

    const bool configured =
        IsCanonEosCompatibility()
            ? ConfigureCanonEos(error)
            : ConfigureGeneric(error);

    if (!configured) {
        const std::wstring prefix =
            IsCanonEosCompatibility()
                ? L"Canon/EOS compatibility: "
                : L"Generic webcam: ";
        error = prefix + error;
        Close();
        return false;
    }

    return true;
}

bool CameraCapture::ReadFrame(std::vector<uint8_t>& bgra,
                              uint32_t& w,
                              uint32_t& h,
                              uint32_t& stride,
                              std::wstring& error)
{
    if (!reader_) {
        error = L"Camera not open";
        return false;
    }

    DWORD streamIndex = 0;
    DWORD flags = 0;
    LONGLONG timestamp = 0;
    ComPtr<IMFSample> sample;

    HRESULT hr = reader_->ReadSample(
        MF_SOURCE_READER_FIRST_VIDEO_STREAM,
        0,
        &streamIndex,
        &flags,
        &timestamp,
        &sample);

    if (FAILED(hr)) {
        error = L"Camera ReadSample failed";
        return false;
    }

    if (flags & MF_SOURCE_READERF_CURRENTMEDIATYPECHANGED) {
        ComPtr<IMFMediaType> actual;
        if (SUCCEEDED(reader_->GetCurrentMediaType(
                MF_SOURCE_READER_FIRST_VIDEO_STREAM, &actual))) {
            UINT32 width = 0, height = 0;
            if (SUCCEEDED(MFGetAttributeSize(
                    actual.Get(), MF_MT_FRAME_SIZE, &width, &height)) &&
                width && height) {
                w_ = width;
                h_ = height;
            }
        }
    }

    if (!sample)
        return false;

    ComPtr<IMFMediaBuffer> buf;
    if (FAILED(sample->ConvertToContiguousBuffer(&buf))) {
        error = L"Could not access camera buffer";
        return false;
    }

    const size_t rowBytes = static_cast<size_t>(w_) * 4;
    bgra.resize(rowBytes * h_);

    // Respect the actual Media Foundation scanline pitch. This works for both
    // the Canon compatibility converter and generic webcam converters.
    ComPtr<IMF2DBuffer> twoD;
    if (SUCCEEDED(buf.As(&twoD))) {
        BYTE* scan0 = nullptr;
        LONG pitch = 0;

        if (SUCCEEDED(twoD->Lock2D(&scan0, &pitch))) {
            const BYTE* firstRow = scan0;

            if (pitch < 0)
                firstRow = scan0 +
                    static_cast<ptrdiff_t>(h_ - 1) * pitch;

            for (uint32_t y = 0; y < h_; ++y) {
                const BYTE* row =
                    (pitch >= 0)
                        ? (scan0 + static_cast<ptrdiff_t>(y) * pitch)
                        : (firstRow - static_cast<ptrdiff_t>(y) * pitch);

                memcpy(
                    bgra.data() + static_cast<size_t>(y) * rowBytes,
                    row,
                    rowBytes);
            }

            twoD->Unlock2D();

            w = w_;
            h = h_;
            stride = static_cast<uint32_t>(rowBytes);
            return true;
        }
    }

    BYTE* data = nullptr;
    DWORD maxLength = 0;
    DWORD currentLength = 0;

    if (FAILED(buf->Lock(&data, &maxLength, &currentLength))) {
        error = L"Could not lock camera buffer";
        return false;
    }

    const size_t required = rowBytes * h_;
    if (currentLength < required) {
        buf->Unlock();
        error = L"Short camera frame";
        return false;
    }

    memcpy(bgra.data(), data, required);
    buf->Unlock();

    w = w_;
    h = h_;
    stride = static_cast<uint32_t>(rowBytes);
    return true;
}

void CameraCapture::Close()
{
    reader_.Reset();
    w_ = h_ = 0;
    deviceName_.clear();
    mode_ = Mode::GenericMediaFoundation;
}
