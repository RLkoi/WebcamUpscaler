@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "ROOT=%~dp0"
set "SDKDIR=%ROOT%FSR3_SDK"
set "CACHE=%SDKDIR%\_extracted"
set "APIHEADER=%CACHE%\ffx-api\include\ffx_api\ffx_api.h"
set "UPSCALEHEADER=%CACHE%\ffx-api\include\ffx_api\ffx_upscale.h"
set "FSR3HOSTHEADER=%CACHE%\sdk\include\FidelityFX\host\ffx_fsr3upscaler.h"
set "DX12HEADER=%CACHE%\ffx-api\include\ffx_api\dx12\ffx_api_dx12.h"
set "RUNTIME=%CACHE%\PrebuiltSignedDLL\amd_fidelityfx_dx12.dll"

if not exist "%SDKDIR%" mkdir "%SDKDIR%"

rem If the exact v1.1.4 layout is already ready, do nothing.
if exist "%APIHEADER%" if exist "%UPSCALEHEADER%" if exist "%FSR3HOSTHEADER%" if exist "%DX12HEADER%" if exist "%RUNTIME%" (
    echo FidelityFX SDK v1.1.4 cache ready.
    exit /b 0
)

set "SDKZIP="
if exist "%SDKDIR%\FidelityFX-SDK-v1.1.4.zip" set "SDKZIP=%SDKDIR%\FidelityFX-SDK-v1.1.4.zip"
if not defined SDKZIP (
    for %%F in ("%SDKDIR%\FidelityFX-SDK-v1.1.4*.zip") do if exist "%%~fF" if not defined SDKZIP set "SDKZIP=%%~fF"
)
if not defined SDKZIP (
    for %%F in ("%SDKDIR%\FidelityFX-SDK*.zip") do if exist "%%~fF" if not defined SDKZIP set "SDKZIP=%%~fF"
)

if not defined SDKZIP (
    echo ERROR: FidelityFX SDK ZIP not found.
    echo Put FidelityFX-SDK-v1.1.4.zip directly inside:
    echo   "%SDKDIR%"
    exit /b 2
)

echo Preparing FidelityFX SDK from:
echo   "%SDKZIP%"
if exist "%CACHE%" rmdir /s /q "%CACHE%"
mkdir "%CACHE%" || exit /b 3

powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%SDKZIP%' -DestinationPath '%CACHE%' -Force"
if errorlevel 1 exit /b 4

rem AMD's v1.1.4 archive normally extracts directly into CACHE. Some ZIP tools
rem may wrap it in a single FidelityFX-SDK-* directory. If that happened,
rem flatten that one wrapper directory so VS always sees the same paths.
if not exist "%UPSCALEHEADER%" (
    set "WRAPPER="
    for /d %%D in ("%CACHE%\FidelityFX-SDK*") do if not defined WRAPPER set "WRAPPER=%%~fD"
    if defined WRAPPER (
        if exist "!WRAPPER!\ffx-api\include\ffx_api\ffx_upscale.h" (
            echo Normalizing wrapped SDK extraction layout...
            powershell -NoProfile -ExecutionPolicy Bypass -Command "$src='%CACHE%'; $w=(Get-ChildItem -LiteralPath $src -Directory -Filter 'FidelityFX-SDK*' | Select-Object -First 1).FullName; Get-ChildItem -LiteralPath $w -Force | Move-Item -Destination $src -Force; Remove-Item -LiteralPath $w -Recurse -Force"
            if errorlevel 1 exit /b 4
        )
    )
)

if not exist "%APIHEADER%" (
    echo ERROR: Exact v1.1.4 header missing:
    echo   ffx-api\include\ffx_api\ffx_api.h
    exit /b 5
)
if not exist "%UPSCALEHEADER%" (
    echo ERROR: Exact v1.1.4 upscaler API header missing:
    echo   ffx-api\include\ffx_api\ffx_upscale.h
    exit /b 6
)
if not exist "%FSR3HOSTHEADER%" (
    echo ERROR: Exact v1.1.4 FSR3 host header missing:
    echo   sdk\include\FidelityFX\host\ffx_fsr3upscaler.h
    exit /b 7
)
if not exist "%DX12HEADER%" (
    echo ERROR: Exact v1.1.4 DX12 API header missing:
    echo   ffx-api\include\ffx_api\dx12\ffx_api_dx12.h
    exit /b 8
)
if not exist "%RUNTIME%" (
    echo ERROR: Exact v1.1.4 runtime missing:
    echo   PrebuiltSignedDLL\amd_fidelityfx_dx12.dll
    exit /b 9
)

echo FidelityFX SDK v1.1.4 prepared successfully.
echo   API:     %UPSCALEHEADER%
echo   FSR3:    %FSR3HOSTHEADER%
echo   Runtime: %RUNTIME%
exit /b 0
