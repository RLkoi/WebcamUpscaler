# WebcamUpscaler V2-X.2.3

V2-X.2.3 is the AMD driver-upgrade branch of WebcamUpscaler V2.1.

## Goal

V2-X.2.3 keeps the working DirectX 12 + signed FidelityFX FSR 3.1 integration, but changes one important part of the FidelityFX API setup: **the application no longer pins the upscaler context to the FSR 3.1 provider**.

AMD's FSR 3.1 integration guidance states that the FidelityFX API chooses the latest compatible provider by default, and that versions supplied by the AMD driver can appear in the API's provider enumeration. This is the mechanism V2-X.2.3 is trying to expose to AMD Software's FSR driver-upgrade feature.

The application does not impersonate or spoof another game. It remains `WebcamUpscaler.exe` with its own Windows version metadata.

## V2-X.2.3 diagnostics

The main window now reports:

- actual successful FidelityFX dispatch state
- effective/default provider
- every upscaling provider exposed by the FidelityFX API
- active GPU name
- AMD DX12 driver module version when available
- loaded FidelityFX DLL version
- AMD driver-upgrade eligibility
- whether an FSR 4 / Redstone / ML upscaling provider appeared in the API enumeration

`DETECTED` means an upgraded provider was genuinely exposed by the FidelityFX API. It is not inferred merely from owning an RX 9000 GPU.

## Testing the AMD override

1. Put `FidelityFX-SDK-v1.1.4.zip` in `FSR3_SDK` and build V2-X.2.3.
2. Run WebcamUpscaler once so AMD Software can discover the executable.
3. Open AMD Software: Adrenalin Edition and check Gaming / Graphics for WebcamUpscaler.
4. If an AMD FSR Upscaling upgrade control is available for the application, enable it while WebcamUpscaler is closed.
5. Launch WebcamUpscaler again and start processing.
6. Check the V2-X.2.3 diagnostics.

With no driver upgrade, the exposed/default provider should remain FSR 3.1. If AMD provides a newer provider through its upgrade mechanism, V2-X.2.3 should report it in `Providers exposed` and mark the driver upgrade as detected.

## Why provider pinning was removed

V2.1 explicitly enumerated providers and attached `ffxOverrideVersion` to request FSR 3.x. That was useful to prove the app was really using FSR 3, but it also prevented the API from freely selecting a newer driver-provided implementation.

V2-X.2.3 still enumerates providers for diagnostics, but context creation leaves provider selection to the FidelityFX API default/latest behavior.

## Current limitation

AMD documents the driver-upgrade feature primarily for supported DX12 games with standard signed FSR 3.1 integrations. WebcamUpscaler is a multimedia application rather than a game, so whether Adrenalin creates an eligible profile for it is something V2-X.2.3 needs to test on real AMD hardware.
