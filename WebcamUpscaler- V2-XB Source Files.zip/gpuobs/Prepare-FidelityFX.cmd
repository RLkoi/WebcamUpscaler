@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "ROOT=%~dp0"
set "SDKDIR=%ROOT%FSR3_SDK"
set "CACHE=%SDKDIR%\_extracted"

if not exist "%SDKDIR%" mkdir "%SDKDIR%"

set "SDKZIP="
if exist "%SDKDIR%\FidelityFX-SDK-v1.1.4.zip" set "SDKZIP=%SDKDIR%\FidelityFX-SDK-v1.1.4.zip"
if not defined SDKZIP (
  for %%F in ("%SDKDIR%\FidelityFX-SDK*.zip") do (
    if exist "%%~fF" if not defined SDKZIP set "SDKZIP=%%~fF"
  )
)

if not defined SDKZIP (
  echo ERROR: FidelityFX SDK ZIP not found.
  echo Put FidelityFX-SDK-v1.1.4.zip directly inside:
  echo   "%SDKDIR%"
  exit /b 2
)

set "HEADER=%CACHE%\ffx-api\include\ffx_api\ffx_api.h"
set "UPSCALE=%CACHE%\ffx-api\include\ffx_api\ffx_upscale.h"
set "DX12HDR=%CACHE%\ffx-api\include\ffx_api\dx12\ffx_api_dx12.h"
set "HOST=%CACHE%\sdk\include\FidelityFX\host\ffx_fsr3upscaler.h"
set "RUNTIME=%CACHE%\PrebuiltSignedDLL\amd_fidelityfx_dx12.dll"

if exist "%HEADER%" if exist "%UPSCALE%" if exist "%DX12HDR%" if exist "%HOST%" if exist "%RUNTIME%" (
  echo FidelityFX SDK v1.1.4 cache ready.
  exit /b 0
)

echo Extracting FidelityFX SDK from:
echo   "%SDKZIP%"

if exist "%CACHE%" rmdir /s /q "%CACHE%"
mkdir "%CACHE%" || exit /b 3

powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%SDKZIP%' -DestinationPath '%CACHE%' -Force"
if errorlevel 1 exit /b 4

rem If the ZIP contains a top-level FidelityFX-SDK-* folder, flatten it.
if not exist "%HEADER%" (
  for /d %%D in ("%CACHE%\*") do (
    if exist "%%~fD\ffx-api\include\ffx_api\ffx_api.h" (
      echo Found SDK root:
      echo   %%~fD
      echo Normalizing SDK folder layout...
      robocopy "%%~fD" "%CACHE%" /E /MOVE >nul
      if errorlevel 8 exit /b 4
      rmdir /s /q "%%~fD" 2>nul
      goto :normalized
    )
  )
)

:normalized

rem Last-resort recursive discovery. If found, copy the real SDK root into CACHE.
if not exist "%HEADER%" (
  set "FOUNDROOT="
  for /r "%CACHE%" %%F in (ffx_api.h) do (
    if /I "%%~nxF"=="ffx_api.h" (
      echo %%~fF | findstr /I "\\ffx-api\\include\\ffx_api\\ffx_api.h$" >nul
      if not errorlevel 1 if not defined FOUNDROOT (
        set "P=%%~dpF"
        for %%A in ("!P!..\..\..") do set "FOUNDROOT=%%~fA"
      )
    )
  )
  if defined FOUNDROOT (
    echo Discovered SDK root:
    echo   !FOUNDROOT!
    if /I not "!FOUNDROOT!"=="%CACHE%" (
      robocopy "!FOUNDROOT!" "%CACHE%" /E >nul
      if errorlevel 8 exit /b 4
    )
  )
)

if not exist "%HEADER%" (
  echo ERROR: AMD FidelityFX v1.1.4 core API header not found:
  echo   "%HEADER%"
  exit /b 5
)
if not exist "%UPSCALE%" (
  echo ERROR: ffx_upscale.h not found:
  echo   "%UPSCALE%"
  exit /b 6
)
if not exist "%DX12HDR%" (
  echo ERROR: ffx_api_dx12.h not found:
  echo   "%DX12HDR%"
  exit /b 7
)
if not exist "%HOST%" (
  echo ERROR: ffx_fsr3upscaler.h not found:
  echo   "%HOST%"
  exit /b 8
)
if not exist "%RUNTIME%" (
  echo ERROR: amd_fidelityfx_dx12.dll not found:
  echo   "%RUNTIME%"
  exit /b 9
)

echo FidelityFX SDK v1.1.4 prepared successfully.
exit /b 0
