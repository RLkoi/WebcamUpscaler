# WebcamUpscaler V2-XB

# WebcamUpscaler V2-XB — Real AMD FSR 3 build

WebcamUpscaler takes a Windows Media Foundation camera source (including Canon EOS Webcam Utility), sends each frame through AMD's **real FidelityFX FSR 3 upscaler on DirectX 12**, then publishes the processed result to OBS through the native shared-GPU-texture source plugin.

## What changed in this build

The old GPU bilinear/linear scaler has been replaced by an actual FidelityFX API dispatch:

```text
EOS / Media Foundation frame
        -> DX12 input texture
        -> ffxDispatch (FSR 3.x provider)
        -> DX12 FSR output texture
        -> D3D11On12 interop
        -> shared GPU texture
        -> OBS WebcamUpscaler source
```

The application runtime-loads FidelityFX SDK v1.1.4's signed `amd_fidelityfx_dx12.dll`. At startup WebcamUpscaler queries the installed upscaler providers and **explicitly selects an FSR 3.x provider** rather than silently accepting FSR 4 when using a newer SDK.

If the local FidelityFX runtime does not report an FSR 3 provider, initialization fails with an error instead of falling back to the old scaler.

## Important webcam limitation

FSR 3 Super Resolution is a temporal game upscaler. A game normally provides current color, depth, motion vectors, camera jitter, exposure and other renderer information. EOS Webcam Utility only gives WebcamUpscaler a finished color image.

For camera use this project therefore uses an **FSR 3 compatibility input**:

- real camera color frame
- flat synthetic depth
- zero motion vectors
- zero render jitter
- automatic exposure

The work is genuinely executed by AMD FSR 3, but it does not have the same motion information available to a game-engine integration. Fast-moving camera subjects may therefore show temporal artifacts. This is the main area for future optical-flow work.

## 2x frame interpolation

The `2x FG` option is still the existing GPU midpoint interpolation between two FSR-upscaled frames. It is **not AMD FSR 3 Frame Generation**. It remains labelled experimental for that reason.

## Local AMD SDK

Put the AMD FidelityFX SDK inside:

```text
FSR3_SDK\
```

This version targets the AMD FSR SDK 2.x layout and expects at least:

```text
FSR3_SDK\Kits\FidelityFX\api\include\ffx_api.h
FSR3_SDK\Kits\FidelityFX\api\include\dx12\ffx_api_dx12.h
FSR3_SDK\Kits\FidelityFX\upscalers\include\ffx_upscale.h
FSR3_SDK\FidelityFX-SDK-v1.1.4.zip
```

The DLL search in the build scripts is recursive, so the exact signed-binary subfolder is allowed to vary by SDK release.

## Build in Visual Studio

Open:

```text
Fsr3VirtualCamera.sln
```

and build x64. The project runs `Copy-FidelityFX.cmd` after building, which copies the AMD loader and upscaler DLLs beside the application automatically.

When it initializes successfully, the status line reports the FSR provider name returned by FidelityFX, e.g. an FSR 3.1.x provider.

## OBS

The OBS plugin remains a native shared-texture source. Build/install it with the provided build system, then in OBS choose:

```text
Sources -> + -> WebcamUpscaler
```

OBS receives the selected full output resolution directly from the GPU. The on-screen preview size does not determine OBS resolution.

## Standalone installer

Run:

```bat
Build-Installer.cmd
```

from a Visual Studio developer environment. The builder verifies that the local FidelityFX headers and signed DX12 DLLs exist, builds the app and OBS plugin, then embeds all required payload files into:

```text
dist\WebcamUpscaler-V2-XB-Setup-x64.exe
```

The target PC only needs that installer. It installs:

- `WebcamUpscaler.exe`
- `amd_fidelityfx_dx12.dll`
- the native OBS source plugin and locale data
- a Start Menu shortcut
- an Apps & Features uninstall entry

No WiX is used.

## AI-developed project

WebcamUpscaler is substantially AI-developed with OpenAI ChatGPT. The project exists because its creator wanted to bypass limitations encountered with Canon EOS Webcam Utility without already being an experienced C++/Windows graphics programmer. The practical development loop has been: idea -> generated implementation -> real Windows/EOS/OBS test -> error report -> code revision.

## Notes

This is experimental software. AMD FSR, FidelityFX, Canon EOS Webcam Utility and OBS are technologies/products of their respective owners. WebcamUpscaler is not affiliated with AMD, Canon, Microsoft, OpenAI or the OBS Project.


## FidelityFX SDK v1.1.4 ZIP setup

Put the untouched `FidelityFX-SDK-v1.1.4.zip` directly in `FSR3_SDK/`. Do not manually extract it. Visual Studio runs `Prepare-FidelityFX.cmd` before compiling, extracts the SDK into `FSR3_SDK/_extracted/`, compiles against `ffx-api/include` and `sdk/include`, and copies `PrebuiltSignedDLL/amd_fidelityfx_dx12.dll` beside `WebcamUpscaler.exe`.


## FSR diagnostic
The main window contains a live FidelityFX diagnostic. `ACTIVE` is shown only after the real `ffxDispatch` call returns `FFX_API_RETURN_OK`. It also shows the selected provider, successful dispatch count, last FidelityFX result, and input/output dimensions.

## Build installer from Visual Studio
Open `Fsr3VirtualCamera.sln`. In Solution Explorer, right-click **WebcamUpscaler Installer** and choose **Build**. This runs the complete Release build, OBS plugin build and native installer packaging. The output is `dist\WebcamUpscaler-V2-XB-Setup-x64.exe`. The installer project is intentionally excluded from normal **Build Solution** so it does not recursively package every time you compile the app.


## V2-XB Hot A/B Provider Comparison
Toggle **Force FSR 3.1** while processing to recreate only the FidelityFX context between frames. Unchecked uses AMD default/latest (including driver FSR 4.x); checked pins the enumerated FSR 3.1 provider. Camera capture, DX12 device and OBS transport remain running. Diagnostics query the provider actually selected.


## FidelityFX SDK v1.1.4 layout
Drop the untouched `FidelityFX-SDK-v1.1.4.zip` into `FSR3_SDK`. The build validates the exact SDK files `ffx-api/include/ffx_api/ffx_upscale.h`, `sdk/include/FidelityFX/host/ffx_fsr3upscaler.h`, and `PrebuiltSignedDLL/amd_fidelityfx_dx12.dll`, then normalizes any single wrapper directory automatically.


## Generic webcam support

WebcamUpscaler automatically chooses its capture path from the selected Media Foundation device name:

- If the friendly name contains **Canon** or **EOS** (case-insensitive), the Canon/EOS Webcam Utility compatibility path is enabled.
- All other cameras use the **Generic Media Foundation** path.

The generic path starts from the webcam's advertised native video formats and lets Media Foundation negotiate hardware/software conversion to the BGRA input used by the GPU pipeline. It retries other native media types if the default format cannot be converted. This is intended for ordinary UVC USB webcams and compatible virtual-camera devices.

The active capture path is shown in the application status when processing starts.


## V2-XB
Fixes a V2-X.2 camera-open regression. Source Reader creation is restored to the exact known-good V2-X.1 attribute set; Canon/EOS vs generic webcam handling now branches only during format negotiation after the reader has been created. Reader failures also report the HRESULT.


## V2-XB
Fixes accidental transparency in OBS by forcing every captured BGRA frame to an opaque alpha value (255) before it enters the FidelityFX/GPU pipeline. This applies to both Canon/EOS compatibility capture and generic webcams.


## V2-XB
Fixes OBS transparency at the actual output stage. WebcamUpscaler's final GPU copy/interpolation shaders now write alpha = 1.0 regardless of the alpha returned by the active FidelityFX provider, and the OBS source explicitly disables blending while drawing the shared camera texture. Capture alpha remains forced opaque as an additional safeguard.

## V2-XB AVCO (Adaptive Variable Capture Optimisations)
Adds a hot-changeable multi-select AVCO (Adaptive Variable Capture Optimisations) drop-down. Motion vectors, autofocus depth, reactive mask, transparency/composition mask, exposure and jitter are independently selectable. Motion/reactive/transparency default on; autofocus depth/exposure/jitter default off. These switches are the UI/feature gates for the AVCO temporal-analysis modules; unfinished generators are not falsely reported as active FSR inputs.
\n\n## V2-XB temporal optimisation implementation\nThe AVCO (Adaptive Variable Capture Optimisations) menu is now wired into the processing path. **Motion vectors** use coarse compression-style block matching between consecutive webcam frames and are uploaded as current-to-previous FSR motion vectors. **Autofocus depth** derives a temporally smoothed relative depth field from local focus/sharpness (not metric depth). **Reactive** and **transparency/composition** masks use motion-compensated temporal disagreement and match confidence. **FSR auto exposure** hot-recreates the FidelityFX context when toggled. **Synthetic jitter** uses a small Halton sequence and remains optional because webcam frames are not physically projection-jittered.\n\nThe algorithms are intentionally conservative first implementations and every component can be hot-disabled independently for cameras/scenes where it makes the image worse.\n

## V2-XB build fix
Normal **Build Solution** no longer invokes the installer project. The FidelityFX pre-build command now uses the correctly quoted `$(ProjectDir)..\Prepare-FidelityFX.cmd` path, including when the project lives in a directory whose name contains spaces.


## V2-XB temporal debug controls
V2-XB now exposes the first-pass AVCO temporal-analysis tuning values in the main application and hot-applies edits while capture is running. Debug View can display processed output, motion vectors (R/G encode X/Y displacement), autofocus-derived depth/focus, reactive mask, composition mask, or block-match confidence. Debug views affect the local preview only; the OBS shared output remains the processed camera image.


## V2-XB menu-bar debug UI
The temporal debug controls were moved out of the main window. The standard Windows menu bar now contains **Debug → View** for processed output/mask selection and **Debug → Temporal tuning...** for a separate hot-edit tuning window. This keeps the main capture UI uncluttered.


## V2-XB temporal consistency/tuning update
Temporal tuning now exposes analysis resolution, motion sensitivity, depth sensitivity, depth consistency and mask-preview smoothing, plus Reset all to defaults. Autofocus depth uses edge-aware spatial hole reconstruction and motion-warped previous depth before temporal blending, which fills isolated black blocks while preserving silhouettes. Debug mask previews use display-only temporal interpolation ("in-between" visual frames) to reduce flicker; this smoothing is never supplied to FidelityFX and therefore cannot contaminate the real temporal inputs.


## AVCO
The configurable capture-analysis/temporal optimisation system is now named **AVCO — Adaptive Variable Capture Optimisations**. AVCO covers the independently selectable motion-vector, autofocus-depth, reactive/composition, exposure and jitter capture optimisations and their associated tuning/debug controls.


## AVCO compile fix
Adds the required C++ `<cmath>` include for `std::lround`, fixes Win64 child-control `HMENU` ID casts by converting through `INT_PTR`, and keeps the installer project opt-in rather than part of normal Build Solution.


## AVCO slider + multi-window debug UI
AVCO tuning now uses Win32 trackbar sliders with live numeric readouts and a Reset all to defaults button. Debug → View no longer replaces the normal camera preview. Each AVCO mask opens in its own independent preview window, and multiple mask windows can remain open simultaneously. The main preview and OBS output always remain the normal processed camera image.
