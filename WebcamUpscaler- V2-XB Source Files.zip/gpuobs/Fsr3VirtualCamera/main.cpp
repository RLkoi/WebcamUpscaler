#include <windows.h>
#include <algorithm>
#include <commctrl.h>
#include <mfapi.h>
#include <atomic>
#include <thread>
#include <vector>
#include <string>
#include <mutex>
#include <chrono>
#include <memory>
#include "CameraCapture.h"
#include "Fsr3Upscaler.h"
#include "../Shared/SharedFrame.h"
#include <cmath>

#pragma comment(lib,"comctl32.lib")
#pragma comment(lib,"mfplat.lib")
#pragma comment(lib,"mf.lib")
#pragma comment(lib,"mfreadwrite.lib")
#pragma comment(lib,"mfuuid.lib")

static HWND gInput = nullptr;
static HWND gResolution = nullptr;
static HWND gStart = nullptr;
static HWND gFrameGen = nullptr;
static HWND gProviderToggle = nullptr;
static HWND gOptimisationsButton = nullptr;
static HMENU gOptimisationsMenu = nullptr;
static HMENU gMainMenu = nullptr;
static HMENU gDebugMenu = nullptr;
static HMENU gDebugViewMenu = nullptr;
static HWND gTuningWindow = nullptr;

enum : UINT {
    IDM_DEBUG_VIEW_OUTPUT = 2201,
    IDM_DEBUG_VIEW_MOTION,
    IDM_DEBUG_VIEW_DEPTH,
    IDM_DEBUG_VIEW_REACTIVE,
    IDM_DEBUG_VIEW_COMPOSITION,
    IDM_DEBUG_VIEW_CONFIDENCE,
    IDM_DEBUG_TUNING = 2210
};
enum : UINT { IDM_OPT_MOTION=2101, IDM_OPT_DEPTH, IDM_OPT_REACTIVE, IDM_OPT_TRANSPARENCY, IDM_OPT_EXPOSURE, IDM_OPT_JITTER };
static std::atomic_bool gOptMotion{true}, gOptDepth{false}, gOptReactive{true}, gOptTransparency{true}, gOptExposure{true}, gOptJitter{false};
static HWND gStatus = nullptr;
static HWND gStats = nullptr;
static HWND gFsrDiag = nullptr;
static HWND gPreview = nullptr;
static HINSTANCE gInstance = nullptr;

static std::vector<CameraInfo> gCameras;
static std::atomic_bool gRunning = false;
static std::thread gThread;

struct DisplayFrame {
    std::vector<uint8_t> pixels;
    uint32_t width = 0;
    uint32_t height = 0;
    uint64_t sequence = 0;
};

static std::mutex gFrameMutex;
static std::shared_ptr<DisplayFrame> gLatestFrame;
static std::atomic_uint64_t gInputFrames = 0;
static std::atomic_uint64_t gOutputFrames = 0;
static std::atomic_uint64_t gGeneratedFrames = 0;
static std::atomic_uint64_t gFsrDispatches = 0;
static std::atomic_uint32_t gFsrLastCode = 0xFFFFFFFFu;
static std::atomic_bool gFsrContextReady = false;
static std::atomic_bool gFsrActive = false;
static std::atomic_uint32_t gFsrInputW = 0, gFsrInputH = 0, gFsrOutputW = 0, gFsrOutputH = 0;
static std::mutex gFsrDiagMutex;
static std::wstring gFsrProvider = L"Not initialized";
static std::wstring gGpuName = L"Not initialized";
static std::wstring gAmdDriverVersion = L"Unknown";
static std::wstring gFfxRuntimeVersion = L"Unknown";
static std::wstring gAvailableProviders = L"Not queried";
static bool gDriverUpgradeDetected = false;
static bool gAmdGpu = false;
static std::atomic_bool gForceFsr31 = false;
enum class MaskView : int { Output=0, Motion, Depth, Reactive, Composition, Confidence };

struct MaskPreviewWindow {
    HWND hwnd = nullptr;
    MaskView view = MaskView::Output;
    std::mutex mutex;
    std::vector<uint8_t> pixels;
    std::vector<uint8_t> previousPixels;
    uint32_t width = 0;
    uint32_t height = 0;
};

static MaskPreviewWindow gMaskWindows[6];
static std::mutex gTemporalDebugMutex;
static TemporalAnalysisResult gTemporalDebug;
static uint32_t gTemporalDebugW=0, gTemporalDebugH=0;

// Exposed temporal tuning variables. These are hot-applied every frame.
static std::atomic_int gMotionBlock{32}, gMotionRadius{12}, gMotionSearchStep{2}, gMotionSampleStep{4};
static std::atomic_int gDepthNearPct{20}, gDepthFarPct{92}, gDepthBlendPct{82};
static std::atomic_int gReactiveFloorMilli{35}, gReactiveGainPct{260};
static std::atomic_int gCompReactivePct{72}, gCompUncertainPct{38};
static std::atomic_int gAnalysisScalePct{100}, gMotionSensitivityPct{100}, gDepthSensitivityPct{100}, gDepthConsistencyPct{72};
static std::atomic_int gMaskPreviewSmoothPct{70};


constexpr UINT WM_VIDEO_FRAME = WM_APP + 1;
constexpr UINT WM_STATS_TICK = WM_APP + 2;

static void SetStatus(const std::wstring& text) {
    if (gStatus) SetWindowTextW(gStatus, text.c_str());
}

static void ParseResolution(std::wstring text, uint32_t& w, uint32_t& h) {
    w = 1920;
    h = 1080;
    const auto p = text.find(L'x');
    if (p != std::wstring::npos) {
        w = static_cast<uint32_t>(_wtoi(text.substr(0, p).c_str()));
        h = static_cast<uint32_t>(_wtoi(text.substr(p + 1).c_str()));
    }
}

static void PublishFrame(const std::vector<uint8_t>& frame, uint32_t w, uint32_t h) {
    auto next = std::make_shared<DisplayFrame>();
    next->pixels = frame;
    next->width = w;
    next->height = h;
    next->sequence = gInputFrames.load();

    {
        std::lock_guard<std::mutex> lock(gFrameMutex);
        gLatestFrame = std::move(next);
    }

    if (gPreview) PostMessageW(gPreview, WM_VIDEO_FRAME, 0, 0);
}

static std::shared_ptr<DisplayFrame> GetLatestFrame() {
    std::lock_guard<std::mutex> lock(gFrameMutex);
    return gLatestFrame;
}

static void PaintVideoWindow(HWND hwnd, HDC dc, bool fullResolution) {
    RECT rc{};
    GetClientRect(hwnd, &rc);
    const int clientW = rc.right - rc.left;
    const int clientH = rc.bottom - rc.top;

    auto frame = GetLatestFrame();
    if (!frame || frame->pixels.empty() || !frame->width || !frame->height || clientW <= 0 || clientH <= 0) {
        FillRect(dc, &rc, static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH)));
        SetBkMode(dc, TRANSPARENT);
        SetTextColor(dc, RGB(220,220,220));
        const wchar_t* text = fullResolution ? L"Waiting for full-resolution output..." : L"Waiting for processed frames...";
        DrawTextW(dc, text, -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        return;
    }

    int drawX = 0, drawY = 0, drawW = clientW, drawH = clientH;
    if (!fullResolution) {
        const double srcAspect = static_cast<double>(frame->width) / frame->height;
        const double dstAspect = static_cast<double>(clientW) / clientH;
        if (dstAspect > srcAspect) {
            drawW = static_cast<int>(clientH * srcAspect);
            drawX = (clientW - drawW) / 2;
        } else {
            drawH = static_cast<int>(clientW / srcAspect);
            drawY = (clientH - drawH) / 2;
        }
    }

    // Paint into a memory DC first. OBS and the on-screen preview only ever see
    // a complete finished frame, which avoids the clear/draw flicker of the old path.
    HDC mem = CreateCompatibleDC(dc);
    HBITMAP bmp = CreateCompatibleBitmap(dc, clientW, clientH);
    HGDIOBJ old = SelectObject(mem, bmp);
    RECT memRc{0,0,clientW,clientH};
    FillRect(mem, &memRc, static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH)));

    BITMAPINFO bmi{};
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = static_cast<LONG>(frame->width);
    bmi.bmiHeader.biHeight = -static_cast<LONG>(frame->height);
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    SetStretchBltMode(mem, HALFTONE);
    StretchDIBits(mem,
                  drawX, drawY, drawW, drawH,
                  0, 0, static_cast<int>(frame->width), static_cast<int>(frame->height),
                  frame->pixels.data(), &bmi, DIB_RGB_COLORS, SRCCOPY);

    BitBlt(dc, 0, 0, clientW, clientH, mem, 0, 0, SRCCOPY);
    SelectObject(mem, old);
    DeleteObject(bmp);
    DeleteDC(mem);
}

static LRESULT CALLBACK VideoWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    const bool fullResolution = false;
    switch (msg) {
    case WM_ERASEBKGND:
        return 1;
    case WM_VIDEO_FRAME:
        InvalidateRect(hwnd, nullptr, FALSE);
        return 0;
    case WM_PAINT: {
        PAINTSTRUCT ps{};
        HDC dc = BeginPaint(hwnd, &ps);
        PaintVideoWindow(hwnd, dc, fullResolution);
        EndPaint(hwnd, &ps);
        return 0;
    }
    case WM_CLOSE:
        // Keep the output surface alive while processing; hiding it would make
        // Window Capture unreliable. Stop processing from the main window instead.
        if (gRunning) {
            ShowWindow(hwnd, SW_MINIMIZE);
            return 0;
        }
        ShowWindow(hwnd, SW_HIDE);
        return 0;
    default:
        return DefWindowProcW(hwnd, msg, wParam, lParam);
    }
}

static void ResizeClient(HWND hwnd, uint32_t width, uint32_t height) {
    RECT rc{0,0,static_cast<LONG>(width),static_cast<LONG>(height)};
    const DWORD style = static_cast<DWORD>(GetWindowLongPtrW(hwnd, GWL_STYLE));
    const DWORD exStyle = static_cast<DWORD>(GetWindowLongPtrW(hwnd, GWL_EXSTYLE));
    AdjustWindowRectEx(&rc, style, FALSE, exStyle);
    SetWindowPos(hwnd, nullptr, 0, 0, rc.right - rc.left, rc.bottom - rc.top,
                 SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
}

static void ShowOutputWindows(uint32_t outW, uint32_t outH) {
    // Human preview only. OBS receives the full-resolution shared frame through
    // the FSR Camera Source plugin, so the size of this window is irrelevant.
    (void)outW; (void)outH;
    ResizeClient(gPreview, 960, 540);
    ShowWindow(gPreview, SW_SHOWNOACTIVATE);
    InvalidateRect(gPreview, nullptr, FALSE);
}

static std::vector<uint8_t> MakeMaskPreview(const TemporalAnalysisResult& r, uint32_t w, uint32_t h, MaskView view)
{
    std::vector<uint8_t> bgra(static_cast<size_t>(w)*h*4,255);
    const size_t n=static_cast<size_t>(w)*h;
    if(view==MaskView::Output) return {};
    for(size_t i=0;i<n;++i){
        uint8_t b=0,g=0,red=0;
        if(view==MaskView::Motion && r.motionRG.size()>=n*2){
            float dx=r.motionRG[i*2]*w, dy=r.motionRG[i*2+1]*h;
            red=static_cast<uint8_t>(std::clamp(128.0f+dx*8.0f,0.0f,255.0f));
            g=static_cast<uint8_t>(std::clamp(128.0f+dy*8.0f,0.0f,255.0f));
            b=128;
        } else {
            float v=0;
            if(view==MaskView::Depth && r.depth.size()>=n) v=1.0f-r.depth[i];
            else if(view==MaskView::Reactive && r.reactive.size()>=n) v=r.reactive[i]/255.0f;
            else if(view==MaskView::Composition && r.composition.size()>=n) v=r.composition[i]/255.0f;
            else if(view==MaskView::Confidence && r.confidence.size()>=n) v=r.confidence[i]/255.0f;
            uint8_t q=static_cast<uint8_t>(std::clamp(v,0.0f,1.0f)*255.0f);
            b=g=red=q;
        }
        bgra[i*4]=b; bgra[i*4+1]=g; bgra[i*4+2]=red; bgra[i*4+3]=255;
    }
    return bgra;
}


static const wchar_t* MaskViewName(MaskView view)
{
    switch(view) {
    case MaskView::Motion: return L"AVCO Motion Vectors";
    case MaskView::Depth: return L"AVCO Depth / Focus Mask";
    case MaskView::Reactive: return L"AVCO Reactive Mask";
    case MaskView::Composition: return L"AVCO Composition Mask";
    case MaskView::Confidence: return L"AVCO Motion Confidence";
    default: return L"AVCO Debug";
    }
}

static LRESULT CALLBACK MaskPreviewWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    auto* state = reinterpret_cast<MaskPreviewWindow*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    switch(msg) {
    case WM_NCCREATE: {
        auto* cs = reinterpret_cast<CREATESTRUCTW*>(lParam);
        state = reinterpret_cast<MaskPreviewWindow*>(cs->lpCreateParams);
        SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(state));
        if (state) state->hwnd = hwnd;
        return TRUE;
    }
    case WM_ERASEBKGND:
        return 1;
    case WM_PAINT: {
        PAINTSTRUCT ps{};
        HDC dc = BeginPaint(hwnd, &ps);
        RECT rc{}; GetClientRect(hwnd, &rc);
        FillRect(dc, &rc, static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH)));

        if (state) {
            std::lock_guard<std::mutex> lock(state->mutex);
            if (!state->pixels.empty() && state->width && state->height) {
                BITMAPINFO bmi{};
                bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
                bmi.bmiHeader.biWidth = static_cast<LONG>(state->width);
                bmi.bmiHeader.biHeight = -static_cast<LONG>(state->height);
                bmi.bmiHeader.biPlanes = 1;
                bmi.bmiHeader.biBitCount = 32;
                bmi.bmiHeader.biCompression = BI_RGB;

                SetStretchBltMode(dc, HALFTONE);
                StretchDIBits(dc,
                    0, 0, rc.right-rc.left, rc.bottom-rc.top,
                    0, 0, static_cast<int>(state->width), static_cast<int>(state->height),
                    state->pixels.data(), &bmi, DIB_RGB_COLORS, SRCCOPY);
            }
        }

        EndPaint(hwnd, &ps);
        return 0;
    }
    case WM_CLOSE:
        ShowWindow(hwnd, SW_HIDE);
        return 0;
    case WM_DESTROY:
        if (state) state->hwnd = nullptr;
        return 0;
    default:
        return DefWindowProcW(hwnd, msg, wParam, lParam);
    }
}

static HWND EnsureMaskPreviewWindow(HWND owner, MaskView view)
{
    const int index = static_cast<int>(view);
    if (index <= 0 || index >= 6) return nullptr;
    auto& state = gMaskWindows[index];
    state.view = view;

    if (state.hwnd) {
        ShowWindow(state.hwnd, SW_SHOWNORMAL);
        SetForegroundWindow(state.hwnd);
        return state.hwnd;
    }

    static bool registered = false;
    if (!registered) {
        WNDCLASSW wc{};
        wc.lpfnWndProc = MaskPreviewWndProc;
        wc.hInstance = gInstance;
        wc.lpszClassName = L"WebcamUpscalerAVCOMaskPreview";
        wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
        RegisterClassW(&wc);
        registered = true;
    }

    state.hwnd = CreateWindowExW(
        WS_EX_TOOLWINDOW,
        L"WebcamUpscalerAVCOMaskPreview",
        MaskViewName(view),
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, 720, 460,
        owner, nullptr, gInstance, &state);

    if (state.hwnd) {
        ShowWindow(state.hwnd, SW_SHOWNORMAL);
        UpdateWindow(state.hwnd);
    }
    return state.hwnd;
}

static void UpdateMaskPreviewWindows(const TemporalAnalysisResult& result, uint32_t w, uint32_t h)
{
    const float smooth = std::clamp(gMaskPreviewSmoothPct.load()/100.0f, 0.0f, 0.95f);

    for (int i=1; i<6; ++i) {
        auto& state = gMaskWindows[i];
        if (!state.hwnd || !IsWindowVisible(state.hwnd)) continue;

        auto mask = MakeMaskPreview(result, w, h, static_cast<MaskView>(i));
        if (mask.empty()) continue;

        std::lock_guard<std::mutex> lock(state.mutex);
        if (state.previousPixels.size() == mask.size()) {
            for (size_t p=0; p<mask.size(); p+=4) {
                for (int c=0; c<3; ++c) {
                    mask[p+c] = static_cast<uint8_t>(std::lround(
                        mask[p+c]*(1.0f-smooth) + state.previousPixels[p+c]*smooth));
                }
                mask[p+3] = 255;
            }
        }

        state.previousPixels = mask;
        state.pixels = std::move(mask);
        state.width = w;
        state.height = h;
        InvalidateRect(state.hwnd, nullptr, FALSE);
    }
}
static void Worker(int cameraIndex, uint32_t outW, uint32_t outH, bool frameGen) {
    CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    MFStartup(MF_VERSION);

    CameraCapture cap;
    std::wstring err;
    fvc::SharedGpuFrameWriter gpuWriter;
    Fsr3Upscaler scaler;

    if (cameraIndex < 0 || cameraIndex >= static_cast<int>(gCameras.size()) ||
        !cap.Open(gCameras[cameraIndex], err)) {
        SetStatus(L"Input error: " + err);
        gRunning = false;
        goto done;
    }

    SetStatus(L"Capture: " + std::wstring(cap.ModeName()) +
              L" | Device: " + cap.DeviceName());

    if (!gpuWriter.Open()) {
        SetStatus(L"Could not create GPU transport for OBS.");
        gRunning = false;
        goto done;
    }

    {
        uint64_t frameNo = 0;
        bool initialized = false;
        uint32_t lastW = 0, lastH = 0;
        auto lastArrival = std::chrono::steady_clock::now();
        double estimatedInputMs = 33.333;

        while (gRunning) {
            std::vector<uint8_t> in;
            uint32_t w = 0, h = 0, stride = 0;

            if (!cap.ReadFrame(in, w, h, stride, err)) {
                Sleep(1);
                continue;
            }
            ++gInputFrames;

            // The on-screen window is intentionally only a lightweight camera
            // preview. OBS receives the full selected output resolution through
            // the shared GPU texture below.
            PublishFrame(in, w, h);

            const auto now = std::chrono::steady_clock::now();
            const double deltaMs = std::chrono::duration<double, std::milli>(now - lastArrival).count();
            lastArrival = now;
            if (deltaMs > 4.0 && deltaMs < 250.0)
                estimatedInputMs = estimatedInputMs * 0.85 + deltaMs * 0.15;

            if (!initialized || w != lastW || h != lastH) {
                scaler.Shutdown();
                if (!scaler.Initialize(w, h, outW, outH, err)) {
                    SetStatus(L"GPU initialization error: " + err);
                    break;
                }
                initialized = true;
                lastW = w;
                lastH = h;
                gFsrContextReady = scaler.UsingFidelityFX();
                gFsrActive = false;
                gFsrDispatches = 0;
                gFsrLastCode = 0xFFFFFFFFu;
                gFsrInputW = w; gFsrInputH = h; gFsrOutputW = outW; gFsrOutputH = outH;
                {
                    std::lock_guard<std::mutex> lock(gFsrDiagMutex);
                    gFsrProvider = scaler.FidelityFXVersion().empty() ? L"Default/latest FSR provider" : scaler.FidelityFXVersion();
                    gGpuName = scaler.AdapterName();
                    gAmdDriverVersion = scaler.AmdDriverVersion();
                    gFfxRuntimeVersion = scaler.FidelityFXRuntimeVersion();
                    gAvailableProviders = scaler.AvailableProviders();
                    gDriverUpgradeDetected = scaler.DriverUpgradeDetected();
                    gAmdGpu = scaler.IsAmdGpu();
                }
                const std::wstring fsrName = scaler.FidelityFXVersion().empty() ? L"default/latest FSR provider" : scaler.FidelityFXVersion();
                const std::wstring upgrade = scaler.DriverUpgradeDetected()
                    ? L" AMD driver upgrade provider detected."
                    : (scaler.IsAmdGpu() ? L" V2-XB is eligible; enable the AMD FSR upgrade in Adrenalin if WebcamUpscaler is listed." : L"");
                SetStatus(frameGen
                    ? (L"V2-XB " + fsrName + L" active." + upgrade + L" OBS source: WebcamUpscaler. Experimental 2x interpolation enabled.")
                    : (L"V2-XB " + fsrName + L" active." + upgrade + L" OBS source: WebcamUpscaler."));
            }

            const bool wantedFsr31 = gForceFsr31.load();
            if (scaler.ForceFsr31() != wantedFsr31) {
                if (!scaler.SetForceFsr31(wantedFsr31, err)) { SetStatus(L"FSR provider switch failed: " + err); gForceFsr31 = scaler.ForceFsr31(); }
                { std::lock_guard<std::mutex> lock(gFsrDiagMutex); gFsrProvider = scaler.FidelityFXVersion(); gDriverUpgradeDetected = scaler.DriverUpgradeDetected() && !scaler.ForceFsr31(); }
            }
            TemporalAnalysisSettings temporal{};
            temporal.motionVectors = gOptMotion.load();
            temporal.autofocusDepth = gOptDepth.load();
            temporal.reactiveMask = gOptReactive.load();
            temporal.transparencyMask = gOptTransparency.load();
            temporal.autoExposure = gOptExposure.load();
            temporal.jitter = gOptJitter.load();
            temporal.motionBlockSize=gMotionBlock.load();
            temporal.motionSearchRadius=gMotionRadius.load();
            temporal.motionSearchStep=gMotionSearchStep.load();
            temporal.motionSampleStep=gMotionSampleStep.load();
            temporal.depthNear=gDepthNearPct.load()/100.0f;
            temporal.depthFar=gDepthFarPct.load()/100.0f;
            temporal.depthTemporalBlend=gDepthBlendPct.load()/100.0f;
            temporal.reactiveNoiseFloor=gReactiveFloorMilli.load()/1000.0f;
            temporal.reactiveGain=gReactiveGainPct.load()/100.0f;
            temporal.compositionReactiveWeight=gCompReactivePct.load()/100.0f;
            temporal.compositionUncertaintyWeight=gCompUncertainPct.load()/100.0f;
            temporal.analysisScalePercent=gAnalysisScalePct.load();
            temporal.motionSensitivity=gMotionSensitivityPct.load()/100.0f;
            temporal.depthSensitivity=gDepthSensitivityPct.load()/100.0f;
            temporal.depthConsistency=gDepthConsistencyPct.load()/100.0f;
            temporal.maskPreviewSmoothing=gMaskPreviewSmoothPct.load()/100.0f;
            if (!scaler.SetTemporalSettings(temporal, err)) { SetStatus(L"FSR optimisation update failed: " + err); break; }

            if (!scaler.UpscaleBGRA(in.data(), stride, err)) {
                gFsrActive = false;
                gFsrLastCode = scaler.LastDispatchCode();
                SetStatus(L"GPU upscale failed: " + err);
                break;
            }
            // ACTIVE is only set after the real FidelityFX ffxDispatch call returned FFX_API_RETURN_OK.
            gFsrActive = scaler.LastDispatchSucceeded();
            gFsrLastCode = scaler.LastDispatchCode();
            gFsrDispatches = scaler.SuccessfulDispatchCount();
            {
                std::lock_guard<std::mutex> lock(gTemporalDebugMutex);
                gTemporalDebug=scaler.TemporalStats();
                gTemporalDebugW=w; gTemporalDebugH=h;
            }
            // Debug masks are rendered in independent windows. The main preview
            // remains the normal processed camera image at all times.
            UpdateMaskPreviewWindows(scaler.TemporalStats(), w, h);

            if (frameGen && scaler.HasPrevious()) {
                uint64_t handle = 0;
                if (scaler.PublishMidpoint(handle, err)) {
                    gpuWriter.Publish(handle, outW, outH, frameNo++, 60);
                    ++gOutputFrames;
                    ++gGeneratedFrames;

                    // Place the synthetic midpoint roughly halfway between real
                    // camera frames. The interpolation itself is GPU-only.
                    const DWORD halfMs = static_cast<DWORD>(std::clamp(estimatedInputMs * 0.5, 1.0, 20.0));
                    Sleep(halfMs);
                }
            }

            uint64_t handle = 0;
            if (!scaler.PublishCurrent(handle, err)) {
                SetStatus(L"GPU publish failed: " + err);
                break;
            }
            gpuWriter.Publish(handle, outW, outH, frameNo++, frameGen ? 60 : 30);
            ++gOutputFrames;
            scaler.CommitCurrentAsPrevious();
        }
    }

    scaler.Shutdown();
    cap.Close();
    gpuWriter.Close();

done:
    MFShutdown();
    CoUninitialize();
}
static void StartStop() {
    if (gRunning) {
        gRunning = false;
        if (gThread.joinable()) gThread.join();
        SetWindowTextW(gStart, L"Start");
        SetStatus(L"Stopped");
        return;
    }

    const int idx = static_cast<int>(SendMessageW(gInput, CB_GETCURSEL, 0, 0));
    wchar_t res[64]{};
    GetWindowTextW(gResolution, res, 64);
    uint32_t w = 0, h = 0;
    ParseResolution(res, w, h);
    const bool frameGen = SendMessageW(gFrameGen, BM_GETCHECK, 0, 0) == BST_CHECKED;

    if (idx < 0) {
        MessageBoxW(nullptr, L"Select an input camera first.", L"WebcamUpscaler", MB_ICONWARNING);
        return;
    }
    if (w > fvc::kMaxWidth || h > fvc::kMaxHeight || w < 64 || h < 64) {
        MessageBoxW(nullptr, L"Resolution must be between 64x64 and 3840x2160.", L"WebcamUpscaler", MB_ICONWARNING);
        return;
    }

    gInputFrames = gOutputFrames = gGeneratedFrames = 0;
    gFsrDispatches = 0;
    gFsrLastCode = 0xFFFFFFFFu;
    gFsrContextReady = false;
    gFsrActive = false;
    gFsrInputW = gFsrInputH = gFsrOutputW = gFsrOutputH = 0;
    { std::lock_guard<std::mutex> lock(gFsrDiagMutex);
        gFsrProvider = L"Not initialized";
        gGpuName = L"Not initialized";
        gAmdDriverVersion = L"Unknown";
        gFfxRuntimeVersion = L"Unknown";
        gAvailableProviders = L"Not queried";
        gDriverUpgradeDetected = false;
        gAmdGpu = false;
    }
    {
        std::lock_guard<std::mutex> lock(gFrameMutex);
        gLatestFrame.reset();
    }

    ShowOutputWindows(w, h);
    gRunning = true;
    SetWindowTextW(gStart, L"Stop");
    if (frameGen)
        SetStatus(L"Running. In OBS add Source -> WebcamUpscaler. Experimental 2x interpolation enabled.");
    else
        SetStatus(L"Running. In OBS add Source -> WebcamUpscaler.");
    gThread = std::thread(Worker, idx, w, h, frameGen);
}

static void ToggleOptimisation(UINT id) {
    std::atomic_bool* f=nullptr;
    switch(id){case IDM_OPT_MOTION:f=&gOptMotion;break;case IDM_OPT_DEPTH:f=&gOptDepth;break;case IDM_OPT_REACTIVE:f=&gOptReactive;break;case IDM_OPT_TRANSPARENCY:f=&gOptTransparency;break;case IDM_OPT_EXPOSURE:f=&gOptExposure;break;case IDM_OPT_JITTER:f=&gOptJitter;break;default:return;}
    bool on=!f->load(); f->store(on);
    CheckMenuItem(gOptimisationsMenu,id,MF_BYCOMMAND|(on?MF_CHECKED:MF_UNCHECKED));
}
static void ShowOptimisationsMenu(HWND hwnd) {
    RECT r{}; GetWindowRect(gOptimisationsButton,&r);
    TrackPopupMenu(gOptimisationsMenu,TPM_LEFTALIGN|TPM_TOPALIGN|TPM_RIGHTBUTTON,r.left,r.bottom,0,hwnd,nullptr);
}


static void SetDebugViewMenuCheck(MaskView view)
{
    if (!gDebugViewMenu) return;
    const UINT first = IDM_DEBUG_VIEW_OUTPUT;
    const UINT last = IDM_DEBUG_VIEW_CONFIDENCE;
    CheckMenuRadioItem(gDebugViewMenu, first, last,
                       first + static_cast<UINT>(view),
                       MF_BYCOMMAND);
}

static void OpenDebugView(HWND owner, MaskView view)
{
    if (view == MaskView::Output) {
        if (gPreview) {
            ShowWindow(gPreview, SW_SHOWNORMAL);
            SetForegroundWindow(gPreview);
        }
        return;
    }
    EnsureMaskPreviewWindow(owner, view);
}

static struct AvcoSliderDef {
    const wchar_t* name;
    int id;
    int minValue;
    int maxValue;
    int defaultValue;
} kAvcoSliders[] = {
    {L"Analysis resolution %", 401, 25, 100, 100},
    {L"Motion block size", 402, 8, 128, 32},
    {L"Motion search radius", 403, 0, 64, 12},
    {L"Motion sensitivity %", 404, 25, 400, 100},
    {L"Depth sensitivity %", 405, 25, 400, 100},
    {L"Depth consistency %", 406, 0, 100, 72},
    {L"Depth history %", 407, 0, 99, 82},
    {L"Reactive threshold x1000", 408, 0, 500, 35},
    {L"Reactive gain %", 409, 1, 1000, 260},
    {L"Composition reactive %", 410, 0, 200, 72},
    {L"Composition uncertainty %", 411, 0, 200, 38},
    {L"Mask preview smoothing %", 412, 0, 95, 70}
};

static int SliderValue(HWND hwnd, int id)
{
    HWND slider = GetDlgItem(hwnd, id);
    return slider ? static_cast<int>(SendMessageW(slider, TBM_GETPOS, 0, 0)) : 0;
}

static void SetSliderLabel(HWND hwnd, int id, int value)
{
    wchar_t text[32]{};
    swprintf_s(text, L"%d", value);
    SetDlgItemTextW(hwnd, id + 1000, text);
}

static void ApplyAvcoSlider(HWND hwnd, int id)
{
    const int v = SliderValue(hwnd, id);
    SetSliderLabel(hwnd, id, v);

    switch (id) {
    case 401: gAnalysisScalePct = v; break;
    case 402: gMotionBlock = v; break;
    case 403: gMotionRadius = v; break;
    case 404: gMotionSensitivityPct = v; break;
    case 405: gDepthSensitivityPct = v; break;
    case 406: gDepthConsistencyPct = v; break;
    case 407: gDepthBlendPct = v; break;
    case 408: gReactiveFloorMilli = v; break;
    case 409: gReactiveGainPct = v; break;
    case 410: gCompReactivePct = v; break;
    case 411: gCompUncertainPct = v; break;
    case 412: gMaskPreviewSmoothPct = v; break;
    }
}

static void ResetAvcoSliders(HWND hwnd)
{
    for (const auto& d : kAvcoSliders) {
        HWND slider = GetDlgItem(hwnd, d.id);
        if (!slider) continue;
        SendMessageW(slider, TBM_SETPOS, TRUE, d.defaultValue);
        ApplyAvcoSlider(hwnd, d.id);
    }
}

static LRESULT CALLBACK TuningWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg) {
    case WM_CREATE: {
        CreateWindowW(L"STATIC", L"AVCO tuning — all sliders apply live",
            WS_CHILD | WS_VISIBLE, 16, 12, 380, 22, hwnd, nullptr, nullptr, nullptr);

        int y = 42;
        for (const auto& d : kAvcoSliders) {
            CreateWindowW(L"STATIC", d.name,
                WS_CHILD | WS_VISIBLE, 16, y, 175, 20,
                hwnd, nullptr, nullptr, nullptr);

            HWND slider = CreateWindowExW(
                0, TRACKBAR_CLASSW, L"",
                WS_CHILD | WS_VISIBLE | TBS_HORZ | TBS_AUTOTICKS,
                192, y-4, 250, 30,
                hwnd, reinterpret_cast<HMENU>(static_cast<INT_PTR>(d.id)),
                gInstance, nullptr);

            SendMessageW(slider, TBM_SETRANGE, TRUE, MAKELPARAM(d.minValue, d.maxValue));
            SendMessageW(slider, TBM_SETPAGESIZE, 0,
                         std::max(1, (d.maxValue-d.minValue)/10));
            SendMessageW(slider, TBM_SETPOS, TRUE, d.defaultValue);

            CreateWindowW(L"STATIC", L"",
                WS_CHILD | WS_VISIBLE | SS_RIGHT,
                448, y, 50, 20,
                hwnd, reinterpret_cast<HMENU>(static_cast<INT_PTR>(d.id+1000)),
                nullptr, nullptr);

            ApplyAvcoSlider(hwnd, d.id);
            y += 36;
        }

        CreateWindowW(L"BUTTON", L"Reset all to defaults",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            170, y+8, 180, 30,
            hwnd, reinterpret_cast<HMENU>(static_cast<INT_PTR>(450)),
            nullptr, nullptr);

        CreateWindowW(L"STATIC",
            L"Mask smoothing is display-only. AVCO/FSR always receives the raw analysis data.",
            WS_CHILD | WS_VISIBLE, 16, y+48, 485, 34,
            hwnd, nullptr, nullptr, nullptr);
        return 0;
    }

    case WM_HSCROLL: {
        HWND slider = reinterpret_cast<HWND>(lParam);
        if (slider) {
            const int id = GetDlgCtrlID(slider);
            if (id >= 401 && id <= 412)
                ApplyAvcoSlider(hwnd, id);
        }
        return 0;
    }

    case WM_COMMAND:
        if (LOWORD(wParam) == 450 && HIWORD(wParam) == BN_CLICKED) {
            ResetAvcoSliders(hwnd);
        }
        return 0;

    case WM_CLOSE:
        ShowWindow(hwnd, SW_HIDE);
        return 0;

    case WM_DESTROY:
        if (gTuningWindow == hwnd) gTuningWindow = nullptr;
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

static void ShowTemporalTuning(HWND owner)
{
    if (gTuningWindow) {
        ShowWindow(gTuningWindow, SW_SHOWNORMAL);
        SetForegroundWindow(gTuningWindow);
        return;
    }

    WNDCLASSW wc{};
    wc.lpfnWndProc = TuningWndProc;
    wc.hInstance = gInstance;
    wc.lpszClassName = L"WebcamUpscalerTemporalTuning";
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    RegisterClassW(&wc);

    gTuningWindow = CreateWindowExW(
        WS_EX_TOOLWINDOW,
        wc.lpszClassName,
        L"WebcamUpscaler V2-XB - Temporal Tuning",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU,
        CW_USEDEFAULT, CW_USEDEFAULT, 530, 590,
        owner, nullptr, gInstance, nullptr);

    if (gTuningWindow) {
        ShowWindow(gTuningWindow, SW_SHOWNORMAL);
        UpdateWindow(gTuningWindow);
    }
}

static void BuildMainMenu(HWND hwnd)
{
    gMainMenu = CreateMenu();
    gDebugMenu = CreatePopupMenu();
    gDebugViewMenu = CreatePopupMenu();

    AppendMenuW(gDebugViewMenu, MF_STRING, IDM_DEBUG_VIEW_OUTPUT, L"Processed output");
    AppendMenuW(gDebugViewMenu, MF_STRING, IDM_DEBUG_VIEW_MOTION, L"Motion vectors");
    AppendMenuW(gDebugViewMenu, MF_STRING, IDM_DEBUG_VIEW_DEPTH, L"Depth / focus mask");
    AppendMenuW(gDebugViewMenu, MF_STRING, IDM_DEBUG_VIEW_REACTIVE, L"Reactive mask");
    AppendMenuW(gDebugViewMenu, MF_STRING, IDM_DEBUG_VIEW_COMPOSITION, L"Composition mask");
    AppendMenuW(gDebugViewMenu, MF_STRING, IDM_DEBUG_VIEW_CONFIDENCE, L"Motion confidence");

    AppendMenuW(gDebugMenu, MF_POPUP,
                reinterpret_cast<UINT_PTR>(gDebugViewMenu), L"View");
    AppendMenuW(gDebugMenu, MF_SEPARATOR, 0, nullptr);
    AppendMenuW(gDebugMenu, MF_STRING, IDM_DEBUG_TUNING, L"Temporal tuning...");

    AppendMenuW(gMainMenu, MF_POPUP,
                reinterpret_cast<UINT_PTR>(gDebugMenu), L"Debug");

    SetMenu(hwnd, gMainMenu);
    DrawMenuBar(hwnd);
}

static LRESULT CALLBACK MainWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    static uint64_t lastIn = 0, lastOut = 0, lastGen = 0;
    switch (msg) {
    case WM_CREATE: {
        BuildMainMenu(hwnd);
        CreateWindowW(L"STATIC", L"Input", WS_CHILD | WS_VISIBLE,
            20, 22, 120, 22, hwnd, nullptr, nullptr, nullptr);
        gInput = CreateWindowW(WC_COMBOBOXW, L"",
            WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST | WS_VSCROLL,
            150, 18, 430, 220, hwnd, reinterpret_cast<HMENU>(static_cast<INT_PTR>(101)), nullptr, nullptr);

        CreateWindowW(L"STATIC", L"Output resolution", WS_CHILD | WS_VISIBLE,
            20, 67, 120, 22, hwnd, nullptr, nullptr, nullptr);
        gResolution = CreateWindowW(WC_COMBOBOXW, L"",
            WS_CHILD | WS_VISIBLE | CBS_DROPDOWN | WS_VSCROLL,
            150, 63, 180, 160, hwnd, reinterpret_cast<HMENU>(static_cast<INT_PTR>(102)), nullptr, nullptr);
        const wchar_t* resolutions[] = { L"1280x720", L"1920x1080", L"2560x1440", L"3840x2160" };
        for (const auto* r : resolutions) SendMessageW(gResolution, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(r));
        SendMessageW(gResolution, CB_SETCURSEL, 1, 0);

        gFrameGen = CreateWindowW(L"BUTTON", L"Experimental GPU 2x frame interpolation",
            WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
            350, 64, 250, 24, hwnd, reinterpret_cast<HMENU>(static_cast<INT_PTR>(104)), nullptr, nullptr);
        gProviderToggle = CreateWindowW(L"BUTTON", L"Force FSR 3.1 (hot A/B comparison)", WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX, 20, 94, 300, 24, hwnd, reinterpret_cast<HMENU>(static_cast<INT_PTR>(105)), nullptr, nullptr);
        gOptimisationsButton = CreateWindowW(L"BUTTON", L"AVCO (Adaptive Variable Capture Optimisations) \x25BE", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 20, 124, 220, 28, hwnd, reinterpret_cast<HMENU>(static_cast<INT_PTR>(106)), nullptr, nullptr);

        gOptimisationsMenu = CreatePopupMenu();
        AppendMenuW(gOptimisationsMenu, MF_STRING|MF_CHECKED, IDM_OPT_MOTION, L"Motion vectors (compression-style)");
        AppendMenuW(gOptimisationsMenu, MF_STRING, IDM_OPT_DEPTH, L"Autofocus depth mask");
        AppendMenuW(gOptimisationsMenu, MF_STRING|MF_CHECKED, IDM_OPT_REACTIVE, L"Reactive mask");
        AppendMenuW(gOptimisationsMenu, MF_STRING|MF_CHECKED, IDM_OPT_TRANSPARENCY, L"Transparency/composition mask");
        AppendMenuW(gOptimisationsMenu, MF_SEPARATOR, 0, nullptr);
        AppendMenuW(gOptimisationsMenu, MF_STRING|MF_CHECKED, IDM_OPT_EXPOSURE, L"FSR auto exposure");
        AppendMenuW(gOptimisationsMenu, MF_STRING, IDM_OPT_JITTER, L"Synthetic jitter offset");

        gStart = CreateWindowW(L"BUTTON", L"Start",
            WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
            350, 100, 130, 34, hwnd, reinterpret_cast<HMENU>(static_cast<INT_PTR>(103)), nullptr, nullptr);

        gStatus = CreateWindowW(L"STATIC",
            L"WebcamUpscaler V2-XB ready. FSR provider is not pinned; driver upgrades are allowed.",
            WS_CHILD | WS_VISIBLE,
            20, 160, 590, 45, hwnd, nullptr, nullptr, nullptr);
        gStats = CreateWindowW(L"STATIC", L"Input 0 fps | Output 0 fps | Generated 0 fps",
            WS_CHILD | WS_VISIBLE,
            20, 210, 590, 24, hwnd, nullptr, nullptr, nullptr);
        gFsrDiag = CreateWindowW(L"STATIC",
            L"WebcamUpscaler V2-XB: NOT INITIALIZED\r\nFSR API: default/latest provider | Driver override: unknown",
            WS_CHILD | WS_VISIBLE,
            20, 240, 650, 150, hwnd, nullptr, nullptr, nullptr);

        gCameras = CameraCapture::Enumerate();
        for (auto& c : gCameras) SendMessageW(gInput, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(c.name.c_str()));
        if (!gCameras.empty()) SendMessageW(gInput, CB_SETCURSEL, 0, 0);
        else SetStatus(L"No Media Foundation cameras found.");

        SetTimer(hwnd, 1, 1000, nullptr);
        return 0;
    }

    case WM_TIMER: {
        const uint64_t in = gInputFrames.load();
        const uint64_t out = gOutputFrames.load();
        const uint64_t gen = gGeneratedFrames.load();
        wchar_t text[160]{};
        swprintf_s(text, L"Input %llu fps | Output %llu fps | Generated %llu fps",
                   static_cast<unsigned long long>(in - lastIn),
                   static_cast<unsigned long long>(out - lastOut),
                   static_cast<unsigned long long>(gen - lastGen));
        lastIn = in; lastOut = out; lastGen = gen;
        if (gStats) SetWindowTextW(gStats, text);

        if (gFsrDiag) {
            std::wstring provider, gpuName, driverVersion, runtimeVersion, providers;
            bool upgradeDetected = false, amdGpu = false;
            {
                std::lock_guard<std::mutex> lock(gFsrDiagMutex);
                provider = gFsrProvider;
                gpuName = gGpuName;
                driverVersion = gAmdDriverVersion;
                runtimeVersion = gFfxRuntimeVersion;
                providers = gAvailableProviders;
                upgradeDetected = gDriverUpgradeDetected;
                amdGpu = gAmdGpu;
            }
            const bool contextReady = gFsrContextReady.load();
            const bool active = gFsrActive.load();
            const uint32_t code = gFsrLastCode.load();
            const uint64_t dispatches = gFsrDispatches.load();
            wchar_t diag[1800]{};
            const wchar_t* state = active ? L"ACTIVE" : (contextReady ? L"READY - WAITING FOR SUCCESSFUL DISPATCH" : L"NOT INITIALIZED");
            wchar_t result[64]{};
            if (code == 0xFFFFFFFFu) wcscpy_s(result, L"N/A");
            else if (code == static_cast<uint32_t>(FFX_API_RETURN_OK)) wcscpy_s(result, L"FFX_API_RETURN_OK");
            else swprintf_s(result, L"FidelityFX code %u", code);

            const wchar_t* upgrade = upgradeDetected
                ? L"DETECTED - upgraded FSR provider exposed by FidelityFX API"
                : (amdGpu ? L"ELIGIBLE / NOT DETECTED - enable AMD FSR upgrade in Adrenalin" : L"NOT ELIGIBLE - active adapter is not AMD");

            swprintf_s(diag,
                L"WebcamUpscaler V2-XB | FSR: %s\r\n"
                L"Effective provider: %s\r\nProvider mode: %s\r\n"
                L"AMD driver upgrade: %s\r\n"
                L"GPU: %s | AMD driver: %s\r\n"
                L"FidelityFX runtime: %s | Dispatches: %llu | Last: %s\r\n"
                L"%ux%u -> %ux%u\r\n"
                L"Providers exposed: %s",
                state, provider.c_str(), gForceFsr31.load() ? L"FORCED FSR 3.1" : L"AMD DEFAULT / DRIVER UPGRADE", upgrade, gpuName.c_str(), driverVersion.c_str(),
                runtimeVersion.c_str(), static_cast<unsigned long long>(dispatches), result,
                gFsrInputW.load(), gFsrInputH.load(), gFsrOutputW.load(), gFsrOutputH.load(), providers.c_str());
            SetWindowTextW(gFsrDiag, diag);
        }
        return 0;
    }

    case WM_COMMAND:
        if (LOWORD(wParam) >= IDM_DEBUG_VIEW_OUTPUT &&
            LOWORD(wParam) <= IDM_DEBUG_VIEW_CONFIDENCE) {
            OpenDebugView(hwnd, static_cast<MaskView>(
                LOWORD(wParam) - IDM_DEBUG_VIEW_OUTPUT));
        }
        else if (LOWORD(wParam) == IDM_DEBUG_TUNING) {
            ShowTemporalTuning(hwnd);
        }
        else if (LOWORD(wParam) == 103) StartStop();
        else if (LOWORD(wParam) == 105 && HIWORD(wParam) == BN_CLICKED) { gForceFsr31 = (SendMessageW(gProviderToggle, BM_GETCHECK, 0, 0) == BST_CHECKED); SetStatus(gForceFsr31.load() ? L"Hot switching to forced FSR 3.1..." : L"Hot switching to AMD default provider..."); }
        else if (LOWORD(wParam) == 106 && HIWORD(wParam) == BN_CLICKED) ShowOptimisationsMenu(hwnd);
        else if (LOWORD(wParam) >= IDM_OPT_MOTION && LOWORD(wParam) <= IDM_OPT_JITTER) ToggleOptimisation(LOWORD(wParam));
        return 0;

    case WM_DESTROY:
        KillTimer(hwnd, 1);
        gRunning = false;
        if (gThread.joinable()) gThread.join();
        if (gPreview) DestroyWindow(gPreview);
        PostQuitMessage(0);
        return 0;
    default:
        return DefWindowProcW(hwnd, msg, wParam, lParam);
    }
}

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, LPWSTR, int show) {
    gInstance = instance;
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    MFStartup(MF_VERSION);

    INITCOMMONCONTROLSEX ic{sizeof(ic), ICC_STANDARD_CLASSES};
    InitCommonControlsEx(&ic);

    WNDCLASSW mainClass{};
    mainClass.lpfnWndProc = MainWndProc;
    mainClass.hInstance = instance;
    mainClass.lpszClassName = L"FsrCameraProcessorWnd";
    mainClass.hCursor = LoadCursor(nullptr, IDC_ARROW);
    mainClass.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
    RegisterClassW(&mainClass);

    WNDCLASSW videoClass{};
    videoClass.lpfnWndProc = VideoWndProc;
    videoClass.hInstance = instance;
    videoClass.lpszClassName = L"FsrVideoSurfaceWnd";
    videoClass.hCursor = LoadCursor(nullptr, IDC_ARROW);
    videoClass.hbrBackground = static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH));
    RegisterClassW(&videoClass);

    HWND mainWindow = CreateWindowW(mainClass.lpszClassName, L"WebcamUpscaler V2-XB",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT, 700, 490, nullptr, nullptr, instance, nullptr);

    gPreview = CreateWindowW(videoClass.lpszClassName, L"FSR Preview",
        WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 960, 540,
        nullptr, nullptr, instance, nullptr);

    ShowWindow(mainWindow, show);
    UpdateWindow(mainWindow);

    MSG msg{};
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    MFShutdown();
    CoUninitialize();
    return static_cast<int>(msg.wParam);
}
