#include "TemporalAnalysis.h"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <limits>

namespace {
inline uint8_t Luma(const uint8_t* p) {
    // BGRA -> limited-cost Rec.709-ish luma.
    return static_cast<uint8_t>((29u*p[0] + 150u*p[1] + 77u*p[2]) >> 8);
}
inline int ClampInt(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
struct BlockInfo { int dx=0, dy=0; float confidence=0.0f; float sharpness=0.0f; };
}

bool TemporalAnalysis::Initialize(uint32_t width, uint32_t height) {
    w_=width; h_=height; Reset();
    return w_ && h_;
}
void TemporalAnalysis::Reset() {
    previousLuma_.clear();
    previousDepth_.clear();
}

void TemporalAnalysis::Analyze(const uint8_t* bgra, uint32_t stride,
                               const TemporalAnalysisSettings& settings,
                               TemporalAnalysisResult& out) {
    const size_t pixels=static_cast<size_t>(w_)*h_;
    std::vector<uint8_t> cur(pixels);
    for(uint32_t y=0;y<h_;++y){
        const uint8_t* row=bgra+static_cast<size_t>(y)*stride;
        for(uint32_t x=0;x<w_;++x) cur[static_cast<size_t>(y)*w_+x]=Luma(row+x*4);
    }

    out.motionRG.assign(pixels*2,0.0f);
    out.depth.assign(pixels,1.0f);
    out.reactive.assign(pixels,0);
    out.composition.assign(pixels,0);
    out.confidence.assign(pixels,0);
    out.averageMotionPixels=0; out.averageConfidence=0; out.averageReactive=0;
    out.hasHistory = previousLuma_.size()==pixels;

    const int scalePct=std::clamp(settings.analysisScalePercent,25,100);
    // Scaling the block/sample footprint gives a useful "analysis resolution"
    // control without resampling the camera frame or changing FSR's texture sizes.
    const float invScale=100.0f/float(scalePct);
    const int block=std::clamp(int(std::lround(settings.motionBlockSize*invScale)),8,128);
    const int searchRadius=std::clamp(settings.motionSearchRadius,0,64);
    const int searchStep=std::clamp(settings.motionSearchStep,1,16);
    const int sampleStep=std::clamp(int(std::lround(settings.motionSampleStep*invScale)),1,16);
    const int bxCount=(static_cast<int>(w_)+block-1)/block;
    const int byCount=(static_cast<int>(h_)+block-1)/block;
    std::vector<BlockInfo> blocks(static_cast<size_t>(bxCount)*byCount);

    float minSharp=std::numeric_limits<float>::max(), maxSharp=0.0f;
    double sumMotion=0.0, sumConf=0.0; size_t blockN=0;

    for(int by=0;by<byCount;++by) for(int bx=0;bx<bxCount;++bx){
        BlockInfo& bi=blocks[static_cast<size_t>(by)*bxCount+bx];
        const int x0=bx*block, y0=by*block;
        const int x1=std::min<int>(x0+block,w_), y1=std::min<int>(y0+block,h_);

        // Focus/sharpness proxy: average local gradient energy. This is not
        // metric depth; it deliberately produces a relative focus-plane mask.
        double sharp=0; int sharpN=0;
        for(int y=std::max(1,y0); y<std::min<int>(y1,h_-1); y+=2)
            for(int x=std::max(1,x0); x<std::min<int>(x1,w_-1); x+=2){
                int gx=std::abs(int(cur[y*w_+x+1])-int(cur[y*w_+x-1]));
                int gy=std::abs(int(cur[(y+1)*w_+x])-int(cur[(y-1)*w_+x]));
                sharp += gx+gy; ++sharpN;
            }
        bi.sharpness=sharpN?float(sharp/sharpN):0.0f;
        minSharp=std::min(minSharp,bi.sharpness); maxSharp=std::max(maxSharp,bi.sharpness);

        if(out.hasHistory && settings.motionVectors){
            uint64_t best=std::numeric_limits<uint64_t>::max(), second=std::numeric_limits<uint64_t>::max(); int bestDx=0,bestDy=0;
            for(int dy=-searchRadius;dy<=searchRadius;dy+=searchStep)
                for(int dx=-searchRadius;dx<=searchRadius;dx+=searchStep){
                    uint64_t sad=0; int n=0;
                    for(int y=y0;y<y1;y+=sampleStep) for(int x=x0;x<x1;x+=sampleStep){
                        int px=x+dx, py=y+dy;
                        if(px<0||py<0||px>=int(w_)||py>=int(h_)){ sad+=255; ++n; continue; }
                        sad += std::abs(int(cur[y*w_+x])-int(previousLuma_[py*w_+px])); ++n;
                    }
                    if(n) sad/=n;
                    if(sad<best){second=best;best=sad;bestDx=dx;bestDy=dy;}
                    else if(sad<second) second=sad;
                }
            bi.dx=bestDx; bi.dy=bestDy;
            if(second!=std::numeric_limits<uint64_t>::max()) bi.confidence=std::clamp((float(second-best)/float(second+1))*settings.motionSensitivity,0.0f,1.0f);
            sumMotion += std::sqrt(double(bestDx*bestDx+bestDy*bestDy)); sumConf+=bi.confidence; ++blockN;
        }
    }
    if(blockN){out.averageMotionPixels=float(sumMotion/blockN); out.averageConfidence=float(sumConf/blockN);}

    // Normalize focus energy robustly enough for a first relative-depth pass.
    float sharpRange=std::max(1.0f,maxSharp-minSharp);
    if(previousDepth_.size()!=pixels) previousDepth_.assign(pixels,1.0f);
    double reactiveSum=0.0;

    for(uint32_t y=0;y<h_;++y) for(uint32_t x=0;x<w_;++x){
        const size_t i=static_cast<size_t>(y)*w_+x;
        const BlockInfo& bi=blocks[static_cast<size_t>(y/block)*bxCount+(x/block)];
        out.confidence[i]=static_cast<uint8_t>(std::lround(std::clamp(bi.confidence,0.0f,1.0f)*255.0f));
        if(settings.motionVectors && out.hasHistory){
            out.motionRG[i*2+0]=float(bi.dx)/float(w_);
            out.motionRG[i*2+1]=float(bi.dy)/float(h_);
        }

        if(settings.autofocusDepth){
            float focus=std::clamp((bi.sharpness-minSharp)/sharpRange,0.0f,1.0f);
            focus=std::clamp((focus-0.5f)*settings.depthSensitivity+0.5f,0.0f,1.0f);
            const float nearDepth=std::clamp(settings.depthNear,0.0f,1.0f);
            const float farDepth=std::clamp(settings.depthFar,nearDepth,1.0f);
            out.depth[i]=farDepth-(farDepth-nearDepth)*focus;
        } else out.depth[i]=1.0f;

        if(out.hasHistory && (settings.reactiveMask||settings.transparencyMask)){
            int px=ClampInt(int(x)+bi.dx,0,int(w_)-1);
            int py=ClampInt(int(y)+bi.dy,0,int(h_)-1);
            float residual=std::abs(int(cur[i])-int(previousLuma_[static_cast<size_t>(py)*w_+px]))/255.0f;
            // Suppress tiny sensor/noise differences, then expand meaningful disagreement.
            float react=std::clamp((residual-settings.reactiveNoiseFloor)*settings.reactiveGain,0.0f,1.0f);
            if(settings.reactiveMask) out.reactive[i]=static_cast<uint8_t>(std::lround(react*255.0f));
            if(settings.transparencyMask){
                const float uncertain=1.0f-bi.confidence;
                float comp=std::clamp(react*settings.compositionReactiveWeight+
                                      uncertain*settings.compositionUncertaintyWeight,0.0f,1.0f);
                out.composition[i]=static_cast<uint8_t>(std::lround(comp*255.0f));
            }
            reactiveSum+=react;
        }
    }
    // Reconstruct the autofocus depth field. Low-confidence/isolated depth
    // samples borrow from nearby samples with similar luma, preserving the
    // silhouette much better than a simple blur. Previous depth is first
    // motion-warped so temporal consistency follows the subject instead of
    // trailing behind them.
    if(settings.autofocusDepth && pixels){
        std::vector<float> reconstructed=out.depth;
        const float consistency=std::clamp(settings.depthConsistency,0.0f,1.0f);
        const int radius=1 + int(std::lround(consistency*2.0f));
        for(uint32_t y=0;y<h_;++y) for(uint32_t x=0;x<w_;++x){
            const size_t i=static_cast<size_t>(y)*w_+x;
            const BlockInfo& bi=blocks[static_cast<size_t>(y/block)*bxCount+(x/block)];
            float sum=out.depth[i], weight=1.0f;
            for(int oy=-radius;oy<=radius;++oy) for(int ox=-radius;ox<=radius;++ox){
                if(!ox&&!oy) continue;
                int nx=ClampInt(int(x)+ox,0,int(w_)-1), ny=ClampInt(int(y)+oy,0,int(h_)-1);
                size_t ni=static_cast<size_t>(ny)*w_+nx;
                float lumaSimilarity=1.0f-std::min(1.0f,std::abs(int(cur[i])-int(cur[ni]))/48.0f);
                float spatial=1.0f/(1.0f+float(ox*ox+oy*oy));
                float wgt=lumaSimilarity*spatial*consistency;
                sum+=out.depth[ni]*wgt; weight+=wgt;
            }
            float spatialDepth=sum/weight;

            float historyDepth=spatialDepth;
            if(out.hasHistory && previousDepth_.size()==pixels){
                int hx=ClampInt(int(x)+bi.dx,0,int(w_)-1);
                int hy=ClampInt(int(y)+bi.dy,0,int(h_)-1);
                historyDepth=previousDepth_[static_cast<size_t>(hy)*w_+hx];
            }
            const float history=std::clamp(settings.depthTemporalBlend*consistency,0.0f,0.96f);
            reconstructed[i]=spatialDepth*(1.0f-history)+historyDepth*history;
        }
        out.depth.swap(reconstructed);
        previousDepth_=out.depth;
    }

    out.averageReactive=pixels?float(reactiveSum/pixels):0.0f;
    previousLuma_.swap(cur);
}
