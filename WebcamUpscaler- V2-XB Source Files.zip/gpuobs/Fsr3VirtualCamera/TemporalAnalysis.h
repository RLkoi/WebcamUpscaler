#pragma once
#include <cstdint>
#include <vector>

struct TemporalAnalysisSettings {
    bool motionVectors = true;
    bool autofocusDepth = false;
    bool reactiveMask = true;
    bool transparencyMask = true;
    bool autoExposure = true;
    bool jitter = false;

    // Exposed V2-XB tuning variables.
    int motionBlockSize = 32;
    int motionSearchRadius = 12;
    int motionSearchStep = 2;
    int motionSampleStep = 4;
    float depthNear = 0.20f;
    float depthFar = 0.92f;
    float depthTemporalBlend = 0.82f;
    float reactiveNoiseFloor = 0.035f;
    float reactiveGain = 2.60f;
    float compositionReactiveWeight = 0.72f;
    float compositionUncertaintyWeight = 0.38f;
    float jitterScale = 1.0f;

    // Analysis/tuning controls.
    int analysisScalePercent = 100;       // 25..100; coarser analysis is smoother/faster
    float motionSensitivity = 1.0f;       // 0.25..4
    float depthSensitivity = 1.0f;        // 0.25..4
    float depthConsistency = 0.72f;       // 0..1; hole fill + motion-assisted history
    float maskPreviewSmoothing = 0.70f;    // display-only interpolation; never fed back to FSR
};

struct TemporalAnalysisResult {
    // FSR expects current->previous motion. Values are normalized UV deltas;
    // motionVectorScale converts them back to render-space pixels.
    std::vector<float> motionRG;       // width * height * 2
    std::vector<float> depth;          // width * height, 0=near 1=far
    std::vector<uint8_t> reactive;     // width * height UNORM
    std::vector<uint8_t> composition;  // width * height UNORM
    std::vector<uint8_t> confidence;   // width * height UNORM
    float averageMotionPixels = 0.0f;
    float averageConfidence = 0.0f;
    float averageReactive = 0.0f;
    bool hasHistory = false;
};

class TemporalAnalysis {
public:
    bool Initialize(uint32_t width, uint32_t height);
    void Reset();
    void Analyze(const uint8_t* bgra, uint32_t stride,
                 const TemporalAnalysisSettings& settings,
                 TemporalAnalysisResult& out);
private:
    uint32_t w_ = 0, h_ = 0;
    std::vector<uint8_t> previousLuma_;
    std::vector<float> previousDepth_;
};
