#pragma once
#include <windows.h>
#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#include <wrl/client.h>
#include <string>
#include <vector>

struct CameraInfo {
    std::wstring name;
    std::wstring symbolicLink;
};

class CameraCapture {
public:
    enum class Mode {
        GenericMediaFoundation,
        CanonEosCompatibility
    };

    static std::vector<CameraInfo> Enumerate();

    bool Open(const CameraInfo& info, std::wstring& error);
    bool ReadFrame(std::vector<uint8_t>& bgra,
                   uint32_t& w,
                   uint32_t& h,
                   uint32_t& stride,
                   std::wstring& error);
    void Close();

    Mode CaptureMode() const { return mode_; }
    bool IsCanonEosCompatibility() const { return mode_ == Mode::CanonEosCompatibility; }
    const std::wstring& DeviceName() const { return deviceName_; }
    const wchar_t* ModeName() const {
        return IsCanonEosCompatibility()
            ? L"Canon/EOS compatibility"
            : L"Generic Media Foundation";
    }

private:
    static bool LooksLikeCanonEos(const std::wstring& name);
    bool ConfigureCanonEos(std::wstring& error);
    bool ConfigureGeneric(std::wstring& error);
    bool RequestRgb32(std::wstring& error);

    Microsoft::WRL::ComPtr<IMFSourceReader> reader_;
    uint32_t w_ = 0;
    uint32_t h_ = 0;
    Mode mode_ = Mode::GenericMediaFoundation;
    std::wstring deviceName_;
};
